import React, { Component } from 'react';
import axios from 'axios';
import UserRow from './UserRow';

export default class AllPosts extends Component {

    constructor(props) {
        super(props);
        this.state = { allposts: [] };
    }
    componentDidMount() {

        axios.get('http://localhost:4000/notes')
            .then(response => {
                console.log(response.data);
                this.setState({ allposts: response.data });
            })
            .catch(function (error) {
                if (error.response) {
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                }
            });

    }
    tabRow() {
        return this.state.allposts.map(function (object, i) {

            return <UserRow obj={object} key={i} />;
        });
    }

    render() {
        return (
            <div className="container">
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <td>ID</td>
                            <td>Title</td>
                            <td>Content</td>
                        </tr>
                    </thead>
                    <tbody>
                        {this.tabRow()}
                    </tbody>
                </table>
            </div>
        );
    }
}