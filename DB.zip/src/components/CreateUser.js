import React, { Component } from 'react';
import axios from 'axios';

export default class CreateUser extends Component {

    constructor(props) {
        super(props);
        this.onChangeHostName = this.onChangeHostName.bind(this);
        this.onChangePort = this.onChangePort.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            title: '',
            content: ''
        }
    }
    onChangeHostName(e) {
        this.setState({
            title: e.target.value
        });
    }
    onChangePort(e) {
        this.setState({
            content: e.target.value
        });
    }
    onSubmit(e) {
        e.preventDefault();
        const serverport = {
            title: this.state.title,
            content: this.state.content
        }
        console.log(serverport);
        axios.post('http://localhost:4000/notes', serverport)
            .catch(function (error) {
                if (error.response) {
                    console.log(error.response.data);
                    console.log(error.response.status);
                    console.log(error.response.headers);
                }
            });

        this.setState({
            title: '',
            content: ''
        });
    }

    render() {
        return (
            <div style={{ marginTop: 50 }}>
                <h3>Add New Post</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Add Post Name:  </label>
                        <input type="text" className="form-control" value={this.state.title} onChange={this.onChangeHostName} />
                    </div>
                    <div className="form-group">
                        <label>Add Post Content: </label>
                        <input type="text" className="form-control" value={this.state.content} onChange={this.onChangePort} />
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Add Post" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}