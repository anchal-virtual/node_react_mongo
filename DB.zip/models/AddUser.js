const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for ServerPort
const Users = new Schema({
  userName: {
    type: String
  },
  UserId: {
      type: Number
  }
},{
    collection: 'users'
});

module.exports = mongoose.model('Users', Users);